<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="./style/reset.css" rel="stylesheet" />
    <link href="./style/style.css" rel="stylesheet" />
    <title>Решай</title>
  </head>
  <body>
    <?php
      include "/script/tomail.php";
    ?>
    <header>
      <nav class="main-menu">
        <div class="main-menu__container container">
          <a href="./index.htm" class="main-menu__img-container scrollto"> </a>

          <!-- <div class="main-menu__links">
            <div class="main-menu__grades grades">
              <a href="/pages/select.html" class="grades__link link-underline"
                >5-7 класс</a
              >
              <a href="/pages/select.html" class="grades__link link-underline"
                >8-9 класс</a
              >
              <a href="/pages/select.html" class="grades__link link-underline"
                >10-11 класс</a
              >
            </div>

            <div class="main-menu__btn-container">
              <button class="one-color-btn one-color-btn--main">Курсы</button>
            </div>
          </div> -->
          <a class="main-menu__phone" href="tel:+79803740656">
            8 (980) 374-06-56
          </a>
        </div>
      </nav>
    </header>

    <main>
      <section class="about">
        <div class="about__container container">
          <div class="about__info info">
            <h1 class="info__title">
              Майский марафон по математике 22 мая - 7 июня
            </h1>

            <div class="info__text">
              <ul>
                <!-- <li>Готовим к ЕГЭ с любого уровня на необходимый</li>
                <li>Развиваем логику и интерес к математике</li>
                <li>Наши выпускники учатся в лучших вузах страны</li> -->
                <li>14 живых уроков по 60-90 минут в конференции Zoom</li>
                <li>
                  Занятия в мини-группах по 5-7 человек с камерами, микрофонами
                  и возможностью задать любые вопросы
                </li>
                <li>
                  Повторим все темы и задания из ОГЭ, дадим только необходимую
                  теорию
                </li>
                <li>
                  Расскажем, как распределить время на экзамене и справиться с
                  волнением
                </li>
              </ul>
            </div>

            <div class="info__buttons">
              <!-- <a href="" class="btn-neo">Записаться</a>
              <a href="#" class="link-underline">Попробовать бесплатно</a> -->
              <a href="#feedback" class="btn-neo">Присоединиться к марафону</a>
            </div>
          </div>

          <div class="about__img-container">
            <img src="./img/photos/header-main.png" alt="Фото преподователя" />
          </div>
        </div>
      </section>

      <section class="marathon">
        <h2 class="marathon__title section-title">Расписание марафона</h2>

        <div class="marathon__grid container">
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">пн</p>
            <div class="lesson__date lesson-stcker">22 мая</div>
            <p class="lesson__text">
              Действия с обыкновенными и десятичными дробями, степенями. Расчеты
              по формулам
            </p>
            <p class="lesson__assignment">Задания: №6, 7, 12</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">вт</p>
            <div class="lesson__date lesson-stcker">23 мая</div>
            <p class="lesson__text">
              Дествия со степенями, корнями, формулы сокращенного умножениия.
              Линейные, квадратные, рациональные уравнения и неравенства, а
              также их системы
            </p>
            <p class="lesson__assignment">Задания: №8, 9, 13</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">ср</p>
            <div class="lesson__date lesson-stcker">24 мая</div>
            <p class="lesson__text">
              Задание ВТОРОЙ ЧАСТИ. Выражения, уревнения, неравенства, системы
            </p>
            <p class="lesson__assignment">Задания: №20</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">чт</p>
            <div class="lesson__date lesson__date--color lesson-stcker">
              25 мая
            </div>
            <p class="lesson__text">ОТДЫХ</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">пт</p>
            <div class="lesson__date lesson-stcker">26 мая</div>
            <p class="lesson__text">
              Теория вероятностей, арифметическая, геометтричесская прогрессии
            </p>
            <p class="lesson__assignment">Задания: №10, 14</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">сб</p>
            <div class="lesson__date lesson-stcker">27 мая</div>
            <p class="lesson__text">
              Задание ВТОРОЙ ЧАСТИ. Задачи на движение, работу, сплавы и смеси
            </p>
            <p class="lesson__assignment">Задания: №21</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">вс</p>
            <div class="lesson__date lesson-stcker">28 мая</div>
            <p class="lesson__text">Графики функций</p>
            <p class="lesson__assignment">Задания: №11</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">пн</p>
            <div class="lesson__date lesson-stcker">29 мая</div>
            <p class="lesson__text">
              Задание ВТОРОЙ ЧАСТИ. Построение графиков функций
            </p>
            <p class="lesson__assignment">Задания: №22</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">вт</p>
            <div class="lesson__date lesson__date--color lesson-stcker">
              30 мая
            </div>
            <p class="lesson__text">ОТДЫХ</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">ср</p>
            <div class="lesson__date lesson-stcker">31 мая</div>
            <p class="lesson__text">
              Треугольники. Их свойства, формулы площадей
            </p>
            <p class="lesson__assignment">Задания: №15, 17, 18, 19</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">чт</p>
            <div class="lesson__date lesson-stcker">01 июня</div>
            <p class="lesson__text">
              Четырехугольники. Их свойства, формулы площадей
            </p>
            <p class="lesson__assignment">Задания: №15, 17, 18, 19</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">пт</p>
            <div class="lesson__date lesson-stcker">02 июня</div>
            <p class="lesson__text">
              Окружности. Углы, касательные, описанные, вписанные окружности
            </p>
            <p class="lesson__assignment">Задания: №16, 18, 19</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">сб</p>
            <div class="lesson__date lesson-stcker">03 июня</div>
            <p class="lesson__text">
              Геометрия ВТОРОЙ ЧАСТИ. Первый уровень сложности
            </p>
            <p class="lesson__assignment">Задания: №23, 24</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">вс</p>
            <div class="lesson__date lesson-stcker">04 июня</div>
            <p class="lesson__text">
              Геометрия ВТОРОЙ ЧАСТИ. Второй уровень сложности
            </p>
            <p class="lesson__assignment">Задания: №24, 25</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">пн</p>
            <div class="lesson__date lesson-stcker">05 июня</div>
            <p class="lesson__text">
              Участки, квартиры, мобильная связь, листы бумаги
            </p>
            <p class="lesson__assignment">Задания: №1-5</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">вт</p>
            <div class="lesson__date lesson__date--color lesson-stcker">
              06 июня
            </div>
            <p class="lesson__text">ОГЭ по русскому языкудание</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">ср</p>
            <div class="lesson__date lesson-stcker">07 июня</div>
            <p class="lesson__text">Шины, страховки, путешествия</p>
            <p class="lesson__assignment">Задания: №1-5</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">чт</p>
            <div class="lesson__date lesson__date--color lesson-stcker">
              08 июня
            </div>
            <p class="lesson__text">ОТДЫХ</p>
          </div>
          <div class="marathon__lesson lesson">
            <p class="lesson__weekday">пт</p>
            <div class="lesson__date lesson__date--color lesson-stcker">
              09 июня
            </div>
            <p class="lesson__text">ЭКЗАМЕН</p>
          </div>
          <div class="marathon__lesson lesson"></div>
          <div class="marathon__lesson lesson lesson--hidden"></div>
        </div>
      </section>

      <!-- <section class="choice">
        <div class="container">
          <div class="choice__cards">
            <div class="choice__card">
              <h3 class="choice__card-name matte-blue-text">Курсы</h3>
              <p class="choice__card-text">
                Смотри видеоуроки в удобное время, выполняй домашнее задание,
                получай обратную связь от преподавателя.
              </p>
              <div class="choice__img-container">
                <img
                  src="./img/arts/presentation.png"
                  alt="Курс"
                  class="choice__img"
                />
              </div>
              <a href="" class="choice__card-btn matte-blue-background"
                >Подробнее &#10140;</a
              >
            </div>

            <div class="choice__card">
              <h3 class="choice__card-name matte-pink-text">Мини-группы</h3>
              <p class="choice__card-text">
                Живые занятия с преподавателем в группе до 6 человек с камерой и
                микрофоном. Внимание каждому ученику и команда единомышленников.
              </p>
              <div class="choice__img-container">
                <img
                  src="./img/arts/people-sitting-on-books.png"
                  alt="Люди на книгах"
                  class="choice__img"
                />
              </div>
              <a href="" class="choice__card-btn matte-pink-background"
                >Подробнее &#10140;</a
              >
            </div>

            <div class="choice__card">
              <h3 class="choice__card-name matte-orange-text">Репетиторы</h3>
              <p class="choice__card-text">
                Занимайся индивидуально с преподавателем. Разработаем план
                работы под каждого ученика для достижения любой цели.
              </p>
              <div class="choice__img-container">
                <img
                  src="./img/arts/teacher-and-triangle.png"
                  alt="Репетитор"
                  class="choice__img"
                />
              </div>
              <a href="" class="choice__card-btn matte-orange-background"
                >Подробнее &#10140;</a
              >
            </div>
          </div>
        </div>
      </section> -->

      <!-- <section class="test-sale">
        <div class="container">
          <div class="test-sale__block">
            <div class="test-sale__info">
              <p class="test-sale__text">
                Пройди тест, определи, какой формат для тебя подходит
              </p>
              <a href="" class="test-sale__test-link"
                >Пройти тест - получить скидку</a
              >
            </div>
          </div>
        </div>
      </section> -->

      <section class="achievements">
        <div class="container">
          <h2 class="achievements__title section-title">
            Почему нам можно доверять?
          </h2>
          <div class="achievements__list">
            <div class="achievements__item achievement">
              <div class="achievement__img-container">
                <img
                  src="./img/icons/chart-grow-up.svg"
                  alt="рост показателей"
                  class="achievement__img"
                />
              </div>
              <div class="achievement__name">+ 50</div>
              <p class="achievement__text">
                Баллов у учеников за курс обучения
              </p>
            </div>

            <div class="achievements__item achievement">
              <div class="achievement__img-container">
                <img
                  src="./img/icons/person-with-star.svg"
                  alt="преподаватель"
                  class="achievement__img"
                />
              </div>
              <div class="achievement__name">365</div>
              <p class="achievement__text">Ежегодное обучение преподавателей</p>
            </div>

            <div class="achievements__item achievement">
              <div class="achievement__img-container">
                <img
                  src="./img/icons/cup.svg"
                  alt=" кубок"
                  class="achievement__img"
                />
              </div>
              <div class="achievement__name">8 лет</div>
              <p class="achievement__text">Успешной работы</p>
            </div>
          </div>
        </div>
      </section>

      <section id="feedback" class="feedback">
        <div class="container">
          <!-- <h2 class="feedback__title section-title">
            Хотите задать дополнительные вопросы?
          </h2> -->
          <h2 class="feedback__title section-title">
            Чтобы присоединиться, оставьте Ваши контакты
          </h2>
          <div class="feedback-container">
            <div class="feedback-container__img-container">
              <img
                src="./img/arts/operator.png"
                alt="оператор"
                class="feedback-container__img"
              />
            </div>

            <div class="feedback-container__form-block">
              <!-- <h3 class="feedback-container__title">Оставьте заявку</h3> -->
              <h3 class="feedback-container__title">
                Мы свяжемся с Вами, ответим на вопросы и запишем на марафон
              </h3>
              <!-- <p class="feedback-container__text">
                для записи на бесплатный урок
              </p> -->
              <form
                action=""
                method="post"
                class="feedback-container__form feedback-form"
              >
                <label for="name" class="feedback-form__name standart-small-text"
                  >Имя*</label
                >
                <input name="name" type="text" pattern="^[А-Яа-яЁё\s]+$" required />

                <label for="phone" class="feedback-form__phone standart-small-text"
                  >Номер телефона*</label
                >
                <input name="phone" class="_tel" type="text" required />

                <!-- <div class="feedback-form__choice">
                  <label>
                    <span class="standart-small-text">Я родитель</span>
                    <input type="radio" name="user-type" value="student" />
                  </label>
                  <label>
                    <span class="standart-small-text">Я школьник</span>
                    <input type="radio" name="user-type" value="parent" />
                  </label>
                </div> -->
                <ul class="feedback-form__choice">
                  <li>
                    <label class="standart-small-text">Я родитель</label>
                    <input name="user-type" value="Родитель" type="radio" name="1" checked />
                    <div class="bullet">
                      <div class="line zero"></div>
                      <div class="line one"></div>
                      <div class="line two"></div>
                      <div class="line three"></div>
                      <div class="line four"></div>
                      <div class="line five"></div>
                      <div class="line six"></div>
                      <div class="line seven"></div>
                    </div>
                  </li>
                  <li>
                    <label class="standart-small-text">Я школьник</label>
                    <input name="user-type" value="Ученик"  type="radio" name="1" />
                    <div class="bullet">
                      <div class="line zero"></div>
                      <div class="line one"></div>
                      <div class="line two"></div>
                      <div class="line three"></div>
                      <div class="line four"></div>
                      <div class="line five"></div>
                      <div class="line six"></div>
                      <div class="line seven"></div>
                    </div>
                  </li>
                </ul>

                <button
                  class="feedback-form__btn one-color-btn one-color-btn--main"
                >
                  Оставить заявку
                </button>

                <p
                  class="feedback-form__personal-data-info standart-small-text"
                >
                  Нажимая на кнопку, Вы принимаете политику обработки данных и
                  согласие на обработку персональных данных
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>

      <section class="reviews">
        <h2 class="reviews__title section-title">
          Ученики и их родители говорят о нас:
        </h2>

        <div class="card-carousel container">
          <div class="card" id="1">
            <div class="card__stars-quotes">
              <div class="card__stars">
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
              </div>
              <div class="card__quotes"></div>
            </div>
            <div class="card__text">
              Здравствуйте! Даша сдала экзамен на 4, спасибо вам! Мы довольны
              результатом, в классе несколько двоек, школьный учитель по
              математике не вкладывает ту информацию, которая необходима, а у
              Даши 4. Мне нравятся занятия! Вы помимо того, что хороший
              преподаватель, еще и хороший друг для моей дочери.
            </div>
            <div class="card__img-container">
              <img src="/img/arts/person/person1.svg" class="card__img" />
            </div>
          </div>

          <div class="card" id="2">
            <div class="card__stars-quotes">
              <div class="card__stars">
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
              </div>
              <div class="card__quotes"></div>
            </div>
            <div class="card__text">
              Замечательная школа с прекрасным преподавателем. Начал готовиться
              к профилю почти без знаний математики. За полгода достиг многого и
              сдал ЕГЭ на хороший балл. Ребята, начавшие заниматься чуть раньше
              соответственно сдали лучше. Все объяснения понятные и доходчивые,
              могу смело рекомендовать и ручаться за эту школу. Отдельная
              благодарность Александре, и удачи ей в дальнейшем развитии.
            </div>
            <div class="card__img-container">
              <img src="/img/arts/person/person2.svg" class="card__img" />
            </div>
          </div>

          <div class="card" id="3">
            <div class="card__stars-quotes">
              <div class="card__stars">
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
              </div>
              <div class="card__quotes"></div>
            </div>
            <div class="card__text">
              Занималась в школе Решай у прекрасного преподавателя Александы.
              Она с уважением относится к каждому ученику, переживает за всех,
              как мама. Уроки проходят весело, благодаря этому информация
              запоминается легко. Саша остается на одной волне с учениками,
              устраивает мини-вечеринки для учеников, нет чистой зубрежки, она
              старается преподнести материал так, чтобы запомнил каждый. Очень
              люблю и скучаю по нашим урокам!
            </div>
            <div class="card__img-container">
              <img src="/img/arts/person/person3.svg" class="card__img" />
            </div>
          </div>

          <div class="card" id="4">
            <div class="card__stars-quotes">
              <div class="card__stars">
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
              </div>
              <div class="card__quotes"></div>
            </div>
            <div class="card__text">
              Занимался в этой школе на протяжении года. Из плюсов хочу отметить
              индивидуальный подход к каждому ученику даже на групповых
              занятиях, во время урока царит дружеская атмосфера, из-за этого не
              страшно задавать вопросы. В общем рекомендую!
            </div>
            <div class="card__img-container">
              <img src="/img/arts/person/person4.svg" class="card__img" />
            </div>
          </div>

          <div class="card" id="5">
            <div class="card__stars-quotes">
              <div class="card__stars">
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
              </div>
              <div class="card__quotes"></div>
            </div>
            <div class="card__text">
              Сдала профильный ЕГЭ на 84 балла и полупила на бюджет в
              Санкт-Петербургский государственный университет. Невероятна рада и
              благодарна. За время подготовки обрела друзей среди
              одногруппников. Еще ценно то, что на занятия я всегда шла с
              радостью. Спасибо!
            </div>
            <div class="card__img-container">
              <img src="/img/arts/person/person6.svg" class="card__img" />
            </div>
          </div>

          <div class="card" id="6">
            <div class="card__stars-quotes">
              <div class="card__stars">
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
              </div>
              <div class="card__quotes"></div>
            </div>
            <div class="card__text">
              Очень нравились занятия в группе, занятия. Все доходчиво
              объяснили, рассказали, благодаря таким урокам начинаешь больше
              любить математику
            </div>
            <div class="card__img-container">
              <img src="/img/arts/person/person5.svg" class="card__img" />
            </div>
          </div>

          <div class="card" id="7">
            <div class="card__stars-quotes">
              <div class="card__stars">
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
                <div class="card__star"></div>
              </div>
              <div class="card__quotes"></div>
            </div>
            <div class="card__text">
              Хочу рассказать про свою подготовку к ЕГЭ по профильной
              математике. В январе написала пробник в школе на порог, это меня
              удивило, я думала, что хорошо знаю предмет. Но судя по всему в
              голове не было системности. Поняла, что мне нужна помощь. Пришла в
              школу Решай по рекомендации подруги. В итоге почти за пол года
              смогла подготовиться и сдала на 72 балла! Мне все разложили по
              полочкам, добавили уверенности в себе. Кстати поступила в МГУ, как
              и мечтала!
            </div>
            <div class="card__img-container">
              <img src="/img/arts/person/person7.svg" class="card__img" />
            </div>
          </div>
        </div>
        <a href="#" class="visuallyhidden card-controller"
          >Carousel controller</a
        >
      </section>

      <footer class="footer">
        <div class="footer__container container">
          <div class="footer__logo-container min-logo">
            <div class="min-logo__img"></div>
            <div class="min-logo__text">школа математики</div>
          </div>

          <div class="footer__info-container footer-info">
            <div class="footer-info__img img-letter"></div>
            <p class="footer-info__text">Наша почта</p>
            <a href="mailto:shoolreshay@gmail.com" class="footer-info__contact"
              >shoolreshay@gmail.com</a
            >
          </div>

          <div class="footer__info-container footer-info">
            <div class="footer-info__img img-phone"></div>
            <p class="footer-info__text">Бесплатная консультация</p>
            <a href="tel:+79803740656" class="footer-info__contact"
              >8-980-374-06-56</a
            >
          </div>

          <div class="footer__btn-container">
            <a href="#feedback" class="btn-neo footer__btn">Оставить заявку</a>
          </div>
        </div>
      </footer>
    </main>

    <script src="./script/inputs.js"></script>
    <script src="./script/carusel.js"></script>
    <script src="./script/scroll.js"></script>
    <script src="./script/marathon.js"></script>
    <script src="https://hammerjs.github.io/dist/hammer.js"></script>
  </body>
</html>
